#!/usr/bin/perl
    # Provides an rss feed of a paid user's LiveJournal friends list
    # Full entries, protected entries, etc.
    # Add to your favorite rss reader as
    # http://your.site.com/cgi-bin/lj_friends.cgi?user=USER&;password=PASSWORD
    use warnings;
#    use strict;
    use WWW::Mechanize;
    use CGI;
#   use HTTP::Cookies
    my $cgi = CGI->new();
    my $form = $cgi->Vars;
    my $blnFlag = 0;
    my $agent = WWW::Mechanize->new();
    $agent->cookie_jar(HTTP::Cookies->new);
    $agent->get("http://screen.yahoo.com/stocks.html");
    die "Can't even get the home page: ", $agent->response->status_line
        unless $agent->success;
open (OUTFILE,">C:\\perl\\code\\StockScreener.txt");
#Set search values
#$agent->form_number('1');
$agent->field("grfy", "Up more than 50%");
$agent->submit();
$Response = $agent->content;
print "First time","\n";
print OUTFILE $Response,"\n\n";
$Response = '';
#while ($blnFlag == 0) {
# can't find this
#       my $link = $agent->find_link( text_regex => qr/Next/i );
#This works fine
       my $link = $agent->find_link( text_regex => qr/privacy/i );
       or die "Can't follow link Next 20 page: ", $agent->response->status_line
        unless $agent->success;
print $link->[0], "\n";
#$agent->find_link( n => 240 ) or die "could not find link";
#$agent->find_link( url_regex => qr/next/i );
  #  $agent->follow_link(text => "Next 20", n => 240) or die "Could not follow link";
print "Additional time","\n";
	$Response = $agent->content;
      print OUTFILE $Response,"\n\n";
#};
#$Response = s/<[^>]+>//g;   # Strip HTML tags
#print OUTFILE $Response,"\n\n";
#$Response = s/\s+/ /g;      # Squash whitespace
#print OUTFILE $Response,"\n\n";
#$Response = s/^ //;         # Strip leading space
#print OUTFILE $Response,"\n\n";
#$Response = s/ $//;         # Strip trailing space
#print OUTFILE $Response,"\n\n";
#$Response = s/&#34;/"/g;    # Replace HTML entity quotes
#print OUTFILE $Response,"\n\n";
#    $agent->follow_link(text => "Next 20", n => 11);

close OUTFILE;

#while (@keys) {
#   print pop(@keys), '=', pop(@values), "\n"; }

