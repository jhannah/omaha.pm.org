#!/usr/bin/perl -w
use strict;
use warnings;
use IO;
use XML::Writer;

# Open a file called books2.xml to catch the output
my $output = new IO::File('>./books2.xml');

# Create an XML writer to generate the output
# Have it write to our just created file with
# line-breaks after the end of an element.
# Each element is indented by four spaces
my $writer = new XML::Writer(OUTPUT => $output, DATA_MODE => 1, DATA_INDENT => 4 );

# Write the standard XML declarion
$writer->xmlDecl("UTF-8","Yes");


# Write the starting (root) node
$writer->startTag('titles');

# Write each of the books as elements, then close that element.
$writer->startTag('title', 'titleid' => 'PC1035', 'name' => 'But Is It User Friendly?', 'price' => '22.95');
$writer->endTag();
$writer->startTag('title', 'titleid' => 'PS1372', 'name' => 'Computer Phobic AND Non-Phobic Individuals: Behavior Variations', 'price' => '21.59' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'BU1111', 'name' => 'Cooking with Computers: Surreptitious Balance Sheets', 'price' => '11.95' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'PS7777', 'name' => 'Emotional Security: A New Algorithm', 'price' => '7.99' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'TC4203', 'name' => 'Fifty Years in Buckingham Palace Kitchens', 'price' => '11.95' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'PS2091', 'name' => 'Is Anger the Enemy?', 'price' => '10.95' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'PS2106', 'name' => 'Life Without Fear', 'price' => '7.00' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'TC3218', 'name' => 'Onions, Leeks, and Garlic: Cooking Secrets of the Mediterranean', 'price' => '20.95' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'PS3333', 'name' => 'Prolonged Data Deprivation: Four Case Studies', 'price' => '19.99' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'PC8888', 'name' => 'Secrets of Silicon Valley', 'price' => '20.00' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'MC2222', 'name' => 'Silicon Valley Gastronomic Treats', 'price' => '19.99' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'BU7832', 'name' => 'Straight Talk About Computers', 'price' => '19.99' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'TC7777', 'name' => 'Sushi, Anyone?', 'price' => '14.99' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'BU1032', 'name' => 'The Busy Executive&apos;s Database Guide', 'price' => '19.99' );
$writer->endTag();
$writer->startTag('title', 'titleid' => 'MC3021', 'name' => 'The Gourmet Microwave', 'price' => '2.99' );
$writer->endTag();

# Close the titles tag
$writer->endTag();

# Finish writing the document
$writer->end();

# Close the file, we're done.
$output->close();