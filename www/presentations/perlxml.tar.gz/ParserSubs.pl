#!/usr/bin/perl -w
use strict;
use warnings;
use Xml::Parser;

# Create an new instance of the Parser object
my $parser = new XML::Parser(Style => 'Subs');

# Start parsing the books.xml file
$parser->parsefile('./books.xml');

# Called when a title element starts
# (when the parser reads <title)
sub title
{
    # The parser, the current tag and the attributes of this
    # element are passed to this function. We really only care
    # about the attributes which are in a hash
    my ($p, $tag, %attr) = @_;
    
 
    # Print the name of the tile and its price
    print sprintf("%-75s ... %7.2f",$attr{"name"},$attr{"price"});
}

# Called when a title element ends
# (when the parser reads />)
sub _title
{
    # Print a new line
    print "\n";
}