#!/usr/bin/perl -w
use strict;
use warnings;
use SOAP::Lite;

# Create an new instance of the SOAP Lite class
# URL is the namespace used in the SOAP message for the payload
# on_action mangles the normal SOAP Lite (RPC) message to work with
# a .NET Web Service, and proxy is the actual URL of the Web Service
my $soap = SOAP::Lite
    -> uri('http://tegels.org/')
    -> on_action( sub { join '/', 'http://tegels.org', $_[1] } )
    -> proxy('http://localhost/SimpleService/math.asmx');

# The method we want to call is the Add in our selected namespace
# (the attr property is another .NETish thing)
my $method = SOAP::Data->name('Add')
    ->attr({xmlns => 'http://tegels.org/'});

# The values we want to use as parameters. Name must match the
# formal parameter names in the method signature
my @params = ( SOAP::Data->name(op1 => 3), 
               SOAP::Data->name(op2 => 4) );
 
# Call that method 
my $result = $soap->call($method => @params);

# Look for a result. If the fault property is 1 (true), something
# went wrong, so display that error message, otherwise display the result
if ($result->fault) {
   print $result->faultstring;
} else {
   print $result->result;
}

