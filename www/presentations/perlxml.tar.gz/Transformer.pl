#!/usr/bin/perl -w
use strict;
use warnings;
use Win32::OLE;
use IO::File;
use Win32::Process;
use Win32;
    
# A string to buffer the output of the transform
my $buffer = '';

# Instance of a DOMDocuments. XSLT is the stylesheet to be applied,
# XDOC is the document to be transformed.
my $xslt = Win32::OLE->new("MsXml2.DOMDocument.4.0");
my $xdoc = Win32::OLE->new("MsXml2.DOMDocument.4.0");

# Untyped container for spawning a view of the HTML document generated
my $spawn;

# Reading in the stylesheet synchronously without resolving any
# included files (read, be as fast as possible)
$xslt->{async} = 0;
$xslt->{resolveExternals} = 0;
$xslt->load("./titles.xsl");

# Same for the books3.xml file
$xdoc->{async} = 0;
$xdoc->{resolveExternals} = 0;
$xdoc->load("./books3.xml");

# Apply the Stylesheet to the document, dumping
# the result (HTML) to our buffer
$buffer = $xdoc->transformNode($xslt);

# Compress out CrLf with just Lf, making the
# HTML look right
$buffer =~ s/\r\n/\n/g;

# Write the buffered HTML to the file
open(OUTF,'>./books.html') || die($!);
print OUTF $buffer;
close OUTF;

# Spawn Amaya to display the HTML file just generated
# or die trying
Win32::Process::Create($spawn,
                       'C:\Program Files\Amaya\Windows\bin\amaya.exe',
                       'amaya c:\perlxml\books.html',
                       0,
                       NORMAL_PRIORITY_CLASS,
                       ".")|| die ErrorReport();