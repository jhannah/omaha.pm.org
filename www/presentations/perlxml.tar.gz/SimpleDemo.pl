#!/usr/bin/perl -w
use strict;
use warnings;
use XML::Simple;

# Create an instance of the parser
my $parser = XML::Simple->new();

# Have the parser read the books.xml file into memory
my $titles = $parser->XMLin('./books.xml',forcearray=>1);

# Get each titles/title element
foreach my $key (keys (%{$titles->{title}})) {
    
    # Print the name of the title and it's price
    print sprintf("%-75s ... %7.2f\n",$key,$titles->{title}->{$key}->{'price'});
}