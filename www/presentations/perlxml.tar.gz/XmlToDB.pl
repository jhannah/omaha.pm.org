#!/usr/bin/perl -w
use strict;
use warnings;
use XML::Parser;
use Win32::OLE;

# Create an instance of a parser to work with that uses "eventing"
my $parser = new XML::Parser(Style => 'Subs');

# Create a database connection to work wtih
my $conn = Win32::OLE->new("ADODB.Connection");

# Start reading the books3.xml file
$parser->parsefile('./books3.xml');
   
# Called when the titles element starts   
sub titles
{
    # Open a connection to the database and
    # report any errors in doing that
    $conn->Open("Provider=SQLOLEDB.1;Persist Security Info=True;User ID=pubs_app;Initial Catalog=pubs;Data Source=localhost;pwd=password");
    if(Win32::OLE->LastError() != 0) { die(Win32::OLE->LastError()); }
}

# Called when a titles element ends
sub _titles
{
    # Close the database connection
    $conn->close();
}

# Called when a title element starts
sub title
{
    # The parser, the current tag and the attributes of this
    # element are passed to this function. We really only care
    # about the attributes which are in a hash    
    my ($p, $tag, %attr) = @_;
    
    # Execute the stored procedure as a T-SQL statement
    my $sql = "exec dbo.procTitles_InsertOrUpdate ";  

    # Building the rest of the SQL statement by appending
    # each of the attributes of the current element as
    # as a parameter
    foreach my $at (keys %attr) {
        if($at eq 'price') {
            $sql = $sql.'@'.$at."=".$attr{$at}.", ";     
        }
        if($at eq 'titleid') {        
            $sql = $sql.'@'.$at."='".$attr{$at}."'";
        }
        if($at eq 'name') {        
            $sql = $sql.'@'.$at."='".$attr{$at}."', ";
        }        
    }
    
    # Execute the SQL statement
    $conn->execute($sql);
    if(Win32::OLE->LastError() != 0) { die(Win32::OLE->LastError()); }   
}
